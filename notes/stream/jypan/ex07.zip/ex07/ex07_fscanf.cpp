// fscanf
#include <iostream> 
#include <cstdio>  

using namespace std; 

int main()
{
    double A[]={1.0/3, 1.0/6, 1.0/7, 1.0/9, 1.0/11};
    int n=sizeof(A)/sizeof(A[0]);
    
    FILE * pf;    
    pf = fopen("out_fscanf.txt","wt"); 
    for(int i=0; i<n; i++)
	    fprintf(pf,"%.6f\n", A[i]);	 
    fclose(pf); 
     
    // ����ֵ������ 
    double x[n];
    pf = fopen("out_fscanf.txt","rt"); 
    for(int i=0; i<n; i++)
    	fscanf(pf, "%lf", x+i); 
    fclose(pf);    
     
    for(int i=0; i<n; i++)
    	printf("x[%d]=%.6f\n", i, x[i]);

    // ���ַ���  
    pf = fopen("out_fscanf.txt","wt"); 
    fprintf(pf,"Hello Math\n");	 
    fclose(pf); 
    
    char str[20]; 
    pf = fopen("out_fscanf.txt","rt"); 
    fscanf(pf, "%s", str);  // ȱʡ�Կո�Ϊ������ 
	fclose(pf);
	
	cout << str << endl;     
             
    return 0; 
}
