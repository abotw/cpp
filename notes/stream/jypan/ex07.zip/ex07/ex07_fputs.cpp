// fputc and fputs
#include <iostream> 
#include <cstdio> 

using namespace std; 

int main()
{
    FILE * pf;    
    char c='A';
    char str[]="Math ECNU";
    
    pf = fopen("out_fput.txt","wt");
    fputc(c,pf);
    fputc('\n',pf);
    fputs(str,pf);   
    fclose(pf);
             
    return 0; 
}
