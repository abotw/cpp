// printf
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <iomanip>

using namespace std; 

int main()
{
    int k=5;
    double a=2.7183;
    
    printf("k=%d, a=%f\n\n", k, a);   
    
    double pi=3.1415926;
    printf("pi=%-12.6f\n", pi);

            
    cout << endl; 
	
    return 0; 
}
