// fprintf
#include <iostream> 
#include <cstdio> 
using namespace std;

int main()
{
    double pi=3.1415926;
    printf("pi=%-12.6f\n", pi);    // ����Ļ�����

    FILE * pf;    
    pf = fopen("out_fprintf.txt","wt");
    fprintf(pf,"pi=%-12.6f\n", pi); // д�뵽�ļ���
    fclose(pf);
	
    return 0;
}
