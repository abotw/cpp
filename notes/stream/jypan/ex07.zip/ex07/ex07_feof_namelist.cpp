// feof
#include <iostream> 
#include <cstdio>  

using namespace std; 

int main()
{  
    FILE * pf; 
	char str[20];    

    pf = fopen("namelist.txt","rt");
    while(!feof(pf))
    { 
    	fscanf(pf, "%s", str);
    	cout << str << endl;
    }		
	fclose(pf);	
	
    return 0; 
}
