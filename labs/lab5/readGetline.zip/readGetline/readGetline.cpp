/*
 * File: readGetline.cpp
 * ---------------------
 * Reading one line, using getline(): readGetline.cpp
 * Input: read.txt
 * Output: readoutput.txt
 * ----------------------------------------------------------------------------------------------
 * CPP, Lab 5, Fall 2024, HFU
 * Last updated: Wed Oct 30 23:14:32 CST 2024
 */

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int const MAX = 51;

int main() {
   // create file object and open the datafile 
   ifstream infile("read.txt");
   if (!infile) {
      cerr << "File could not be opened." << endl;
      return 1;
   }

   // getline with arrays
   for (;;) {
      char s[MAX];
      infile.getline(s, MAX);
      if (infile.eof()) break;
      cout << s << endl;
   }
   infile.close();

   cout << "----------------------------------------------------------" << endl;
   // do it all again with strings
   ifstream infile2("read.txt");
   if (!infile2) {
      cerr << "File could not be opened." << endl;
      return 1;
   }

   // getline with strings
   for (;;) {
      string s;   
      getline(infile2,s, '\n');
      if (infile2.eof()) break;
      cout << s << endl;
   }
   infile2.close();

   
   return 0;
}

